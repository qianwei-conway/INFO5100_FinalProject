-- MySQL dump 10.13  Distrib 8.0.11, for macos10.13 (x86_64)
--
-- Host: localhost    Database: project
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8mb4 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `candyJob`
--

DROP TABLE IF EXISTS `candyJob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `candyJob` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(60) NOT NULL,
  `company` text NOT NULL,
  `position` text NOT NULL,
  `instancy` tinyint(1) NOT NULL,
  `returnOffer` tinyint(1) NOT NULL,
  `duty` text NOT NULL,
  `requirement` text,
  `benefit` text,
  `internTime` text,
  `location` text NOT NULL,
  `remote` tinyint(1) NOT NULL,
  `applyLink` text NOT NULL,
  `applyInstruction` text,
  `deadline` date NOT NULL DEFAULT '9999-12-31',
  `otherInfo` text,
  `intro` text,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `candyJob`
--

LOCK TABLES `candyJob` WRITE;
/*!40000 ALTER TABLE `candyJob` DISABLE KEYS */;
INSERT INTO `candyJob` VALUES (1,'abby','Apple','SDE intern',1,1,'lhwlhelihviwjdv','bwkhvpjwopvjp','bwdkbvlkwbdvlk','vlbdk;kwdnv;','Seattle',0,'abc@gmail.com','berkgbjlehr','2022-12-31','vkehoej',NULL),(5,'conway','Zoom','SDE intern',0,1,'1.khwlv.bhkjcgkwhdjchodc.jbksdvkjcbd','1.khwlv.bhkjcgkwhdjchodc.jbksdvkjcbd','1.khwlv.bhkjcgkwhdjchodc.jbksdvkjcbd','From 2023-01-01 and at least 6 months.','Shenzhen, Beijing, Shanghai',0,'cbjwjg@outlook.com','pls name your resume as dcnjskdhvlld','2022-12-15','cjkhgfgjdjgfhgjhfkfg','our company is ...'),(8,'conway','Amazon','SDE internn',0,0,'clhwlvlhldkjv','','','','California',0,'chwhleihfihw','','2023-02-01','','wedhwjkhwkf'),(9,'david','Twitter','SDE intern',0,1,'dfbdrgnd','','','','Seattle',1,'fvdfgdrjntyyn','','2023-02-20','bvretbdfthgnfygn',''),(10,'elan','Amazon','vrgberg',1,0,'gbdfgndgn','gnbdgnbdrg','rgfbdfg',NULL,'Shenzhen',0,'dfdfvdfcvdfcv','dfvsedv','2023-01-21','efgbdrnb','egthdthyh'),(12,'bobby','Appleee','Strategic Operation Intern',0,1,'wechwidhsclic','evwdvwdvewsdv','efbergndtynftgndtgdnfvb ','rgbefgbrgbe','Shenzhen',0,'ethwrfbsfbsefgbv','efvsefbsfbdfrvs','2023-04-03','ergwefvsdfbvsfbv','efvsefbvsrrfbsrfbabcabc'),(14,'conway','amazon','sales intern',1,0,'dajdlkvalsfnvlkdfv\n1.snlcbsldlc\n2. hkshcjshdloc\n3. hksjdhsd','1. dhlchwspvc\n2. jhlsfhlskdc','ldhlaihowd','fdajflandvknskvd','seattle, beijing, hangzhou',1,'we.whouchidhocksoplv','wefkjhawdhcijapvc','2022-12-30','qwldjhalioipqijpw','wefnqljhwslchqljc;lknlsjhlc\nmw,dncbsd\n\nwjckjhskbc\nwljbevkwhbod\nkndlcn\n12345'),(15,'abby','bloomberg','SDE entry level',1,1,'wevwadscalkxlckna\nscknasldc\n\nlnclansl\nqlslkcn','ascajdkvhclauhwd;oichvkxnhlc','wcjwscodvc','sdcjhshcisihcpijasd;l ksdc.ljsochqiuhodf83e29fpqpcjon','seattle',0,'welwqhjslichkhdkljchlskhdpk p;sde','fwqhscughshcl kahlxh ij8y39r987t65456789','2023-01-31','webclahbkscihygiqdohqoyfw3fuykjsc\nncklja\n\nashbvcjhvaksdcgo\n1. jbkjsgbc\n2. kbskjchlsc\n3. bkwclh;dhcvoshkdef','efcfwjbjvchowhoeldkc'),(16,'abby','yahoo','sales intern',0,0,'qwdJshlchlsbc\nqsjlahsckn\nqsjkqhcocphqoishcqohspo[pa;s','wdkGkwchiwdgvloiw;oeugvfw9oefyw978o9ufi3jlnkev','sdvmskhlvcj;psd','vasbsfb','dfbserthbsefnbsrgb',0,'efbah;whi4t78ywebdflcjksv','dvaldiv;pawoeihflkn;dlmcv[ospo','2023-02-28','weljfhlhsdolkjclobso8g4ugbdjmv','wevhdvuoahdvoia\ndvnlsandv\nsvlsbv;nodj;lvm'),(17,'elan','bloomberg','vqbwedjlv',1,0,'weqwdjbvckw\'whvciqbdjvbedv\nwebcjqwolb','webqkwdcibadvc\"wdbckqbdkjcbjdc\"\nwncjqbdcljbwd\nwdjbckljqwbdcpwndpwd','wdbwfnethertjhe56uhdvstheju','ergqhpreghpqpvikwefgv','rgnnohqonvpwerfv',1,'ergpqjerpgivhqpohrgovienrbv','3eglnpihgpiqhpeovdn','2023-02-09','ergqeporbhngvihnrpv','qweflknqofhqouwhdkqaedv'),(18,'david','Twitter','cjwodvc',0,1,'wcbkwbdljvcwdbnvlnwldv\'wdvnkjbvc\'','qscqosnco','wsdcnwlkdsc','qcbjoqjsc','wjowqspck',0,'welcnbqlsncok','wclnwpncpkwsd','2023-01-31','scbkwbsdocjb','scboqscbowjbdsc'),(19,'elan','Northeastern','TA',1,0,'teach students kqsgkwhlschlogdoc gcougshc\ncbkqagskcb\nscbwlkshcp;sc;qdkcn\nsjiwgeuvhvklnsdv\nsdbckalkchos','wedvbkwgdbicjbs\nscbajsdc\n\n\nasdnlkschpowlsdc\nqsbckjqwhdosc','scnqhgsoc','cjhbosuoqhspocjpihwhqoihvclwd','Seattle, Boston',1,'efvqhvkkhjwvdkjhcbkbxkbxs','fdbsdfbvsedfbsfdgbdxdfvb','2023-01-08','wefhcwidgcugaidguvkubvkdc','geukgwodhovc9whieuyv78giwughdnm');
/*!40000 ALTER TABLE `candyJob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `candyUser`
--

DROP TABLE IF EXISTS `candyUser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `candyUser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `identity` varchar(30) NOT NULL,
  `username` varchar(60) NOT NULL,
  `password` varchar(60) DEFAULT NULL,
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `candyUser`
--

LOCK TABLES `candyUser` WRITE;
/*!40000 ALTER TABLE `candyUser` DISABLE KEYS */;
INSERT INTO `candyUser` VALUES (1,'Student','abc','123456'),(2,'Hiring Manager','elan','123456'),(5,'Hiring Manager','abby','123456'),(6,'Hiring Manager','bobby','123456'),(8,'Student','abcd','123456'),(9,'Student','abcde','123456'),(10,'Hiring Manager','david','123456'),(12,'Hiring Manager','conway','123456'),(13,'Student','abcdef','123456');
/*!40000 ALTER TABLE `candyUser` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-12 19:43:53
